from adotesty import runtests
mod = 10 ** 9 + 7

def function(n, m):
    n = str(n)
    dp = [[0 for _ in range(10)] for _ in range(2)]

    for i in n:
        dp[0][int(i)] += 1

    for i in range(m):
        for j in range(1, 10):
            dp[(i + 1) % 2][j] = dp[i % 2][j - 1]
        dp[(i + 1) % 2][0] = 0
        dp[(i + 1) % 2][0] += dp[i % 2][9]
        dp[(i + 1) % 2][1] += dp[i % 2][9]
        for j in range(10):
            dp[(i + 1) % 2][j] = dp[(i + 1) % 2][j] % mod

    output = 0
    for i in dp[m % 2]:
        output += i

    return output % mod


# zmien all_tests na: 
# 0 dla pierwszego progu złożoności 
# 1 dla drugiego progu złożoności
# 2 dla wzorcowego rozwiązania
runtests(function, all_tests = 2)
