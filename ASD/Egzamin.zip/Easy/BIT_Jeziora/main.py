from collections import deque


class Vertex:
    def __init__(self, val):
        self.val = val
        self.visited = False
        self.parent = None

    def __str__(self):
        return f'Index: {self.val}, visited: {self.visited}'


def makeGraphWater(matrix):
    n = len(matrix)
    G = [[] for _ in range(n ** 2)]

    for i in range(n):
        for j in range(n):
            verticleNum = i * n + j
            if matrix[i][j] == 'W':
                if i - 1 >= 0 and matrix[i - 1][j] == 'W':
                    G[verticleNum].append(verticleNum - n)
                if i + 1 < n and matrix[i + 1][j] == 'W':
                    G[verticleNum].append(verticleNum + n)
                if j - 1 >= 0 and matrix[i][j - 1] == 'W':
                    G[verticleNum].append(verticleNum - 1)
                if j + 1 < n and matrix[i][j + 1] == 'W':
                    G[verticleNum].append(verticleNum + 1)

    return G


def makeGraphLand(matrix):
    n = len(matrix)
    G = [[] for _ in range(n ** 2)]

    for i in range(n):
        for j in range(n):
            verticleNum = i * n + j
            if matrix[i][j] == 'L':
                if i - 1 >= 0 and matrix[i - 1][j] == 'L':
                    G[verticleNum].append(verticleNum - n)
                if i + 1 < n and matrix[i + 1][j] == 'L':
                    G[verticleNum].append(verticleNum + n)
                if j - 1 >= 0 and matrix[i][j - 1] == 'L':
                    G[verticleNum].append(verticleNum - 1)
                if j + 1 < n and matrix[i][j + 1] == 'L':
                    G[verticleNum].append(verticleNum + 1)

    return G


def DFSLakes(ListOfVertices, FlatedGraph):
    def DFSVisit(ListOfVertices, FlatedGraph, i):
        nonlocal time
        time += 1
        ListOfVertices[i].visited = True
        for neighbour in FlatedGraph[i]:
            if not ListOfVertices[neighbour].visited:
                DFSVisit(ListOfVertices, FlatedGraph, neighbour)

    counter = 0
    max_time = 0
    for v in ListOfVertices:
        time = 0
        if len(FlatedGraph[v.val]) > 0 and not v.visited:
            counter += 1
            DFSVisit(ListOfVertices, FlatedGraph, v.val)
            max_time = max(max_time, time)
    return counter, max_time


def BSFPath(ListOfVertices, FlatedGraph):
    queue = deque()
    for vertex in ListOfVertices:
        vertex.visited = False
    ListOfVertices[0].visited = True
    queue.append(0)
    found = False
    while queue and not found:
        current = queue.popleft()
        for neighbour in FlatedGraph[current]:
            if not ListOfVertices[neighbour].visited:
                ListOfVertices[neighbour].visited = True
                ListOfVertices[neighbour].parent = current
                if neighbour == len(FlatedGraph) - 1:
                    found = True
                    break
                queue.append(neighbour)
    if not found:
        return False
    return True


def findPath(ListOfVertices):
    Path = []
    curr = len(ListOfVertices) - 1
    while ListOfVertices[curr].parent is not None:
        Path.append(curr)
        curr = ListOfVertices[curr].parent
    return Path[::-1]


# jednak nie potrzebne
# def DFSPath(ListOfVertices, FlatedGraph):
#     def DFSVisit(ListOfVertices, FlatedGraph, i):
#         ListOfVertices[i].visited = True
#         for neighbour in FlatedGraph[i]:
#             if neighbour == len(FlatedGraph) - 1:
#                 return True
#             if not ListOfVertices[neighbour].visited:
#                 if DFSVisit(ListOfVertices, FlatedGraph, neighbour):
#                     return True
#         return False
#
#     return DFSVisit(ListOfVertices, FlatedGraph, 0)

def countSmallLakes(matrix, FlatedLakeGraph):
    counter = 0
    n = len(matrix)
    for i in range(n):
        for j in range(n):
            if matrix[i][j] == 'W' and len(FlatedLakeGraph[i * n + j]) == 0:
                counter += 1
    return counter


def solution(matrix):
    FlatedLakeGraph = makeGraphWater(matrix)
    FlatedPathGraph = makeGraphLand(matrix)
    ListOfVertices = [Vertex(i) for i in range(len(FlatedLakeGraph))]

    numberOfLake, bigestLake = DFSLakes(ListOfVertices, FlatedLakeGraph)
    numberOfLake += countSmallLakes(matrix, FlatedLakeGraph)
    if bigestLake == 0 and numberOfLake > 0:
        bigestLake = 1
    isPathExists = BSFPath(ListOfVertices, FlatedPathGraph)
    if isPathExists:
        Path = findPath(ListOfVertices)
        return numberOfLake, bigestLake, True, Path
    else:
        return numberOfLake, bigestLake, False, []
    # isPathExists = DFSPath(ListOfVertices, FlatedPathGraph)


if __name__ == '__main__':
    matrix = [
        ['L', 'W', 'L', 'L', 'L', 'L', 'L', 'L'],
        ['L', 'W', 'L', 'W', 'W', 'L', 'L', 'L'],
        ['L', 'L', 'L', 'W', 'W', 'L', 'W', 'L'],
        ['L', 'W', 'W', 'W', 'W', 'L', 'W', 'L'],
        ['L', 'L', 'W', 'W', 'L', 'L', 'L', 'L'],
        ['L', 'W', 'L', 'L', 'L', 'L', 'W', 'W'],
        ['W', 'W', 'L', 'W', 'W', 'L', 'W', 'L'],
        ['L', 'L', 'L', 'W', 'L', 'L', 'L', 'L'],
    ]

    n = len(matrix)
    ListOfNumbers = [[j * 8 + i for i in range(n)] for j in range(n)]
    for line in ListOfNumbers:
        print(line)
    numberOfLake, biggestLake, isPathExists, Path = solution(matrix)
    if isPathExists:
        print(f'Biggest lake: {biggestLake}, number of lakes: {numberOfLake}, path: {len(Path)}')
    else:
        print(f'''Biggest lake: {biggestLake}, number of lakes: {numberOfLake}, path: doesn't exist''')
