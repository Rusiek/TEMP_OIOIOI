from adotesty import runtests

def function(t, tab_n, tab_m):
    # Tutaj wprowadź kod
    return [0]

# zmien all_tests na: 
# 0 dla pierwszego progu złożoności 
# 1 dla drugiego progu złożoności
# 2 dla wzorcowego rozwiązania
runtests(function, all_tests = 2)
