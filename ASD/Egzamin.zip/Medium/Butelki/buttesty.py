# zad1testy.py
from testy import *
from buttest_spec import ALLOWED_TIME, TEST_SPEC

def copyarg( arg ):
    return arg

# To należy ustawić do zadania
def check(vol, start, hint, sol):
    output = True
    if len(hint) != len(sol):
        output = False
    else:
        for i in range(len(sol)):
            output = output and hint[i] == sol[i]
    return output

# To należy ustawić do zadania
def gentest(vol, start, output):
    return (vol, start), output

def runtests( f, all_tests = 1 ):
    TESTS = []
    for spec in TEST_SPEC:
        newtest = {}
        arg, hint = gentest(*spec)
        newtest["arg"] = arg
        newtest["hint"] = hint
        TESTS.append(newtest)

    internal_runtests(copyarg, check, TESTS, f, ALLOWED_TIME, all_tests)

