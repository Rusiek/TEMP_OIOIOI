# zad1testy.py
from collections import deque
from testy import *
from dagtest_spec import ALLOWED_TIME, TEST_SPEC

def copyarg( arg ):
    return arg

def DFS(G):
    return True

# To należy ustawić do zadania
def check(k, hint, sol):
    output = True
    # Check node limit
    if sol[0] > 100:
        output = False
    # Check correct len of array
    if sol[0] != len(sol[1]):
        output = False
    # Check for double edgeds
    if output:
        for i in range(sol[0]):
            if sol[1][i][0] == -1 or sol[1][i][1] == -1:
                continue
            else:
                if sol[1][i][0] == sol[1][i][1]:
                    output = False
    # Make graph
    Graph = [[0 for _ in range(sol[0])] for _ in range(sol[0])]
    if output:
        for i in range(sol[0]):
            if sol[1][i][0] != -1:
                Graph[i][sol[1][i][0] - 1] = 1
            if sol[1][i][1] != -1:
                Graph[i][sol[1][i][1] - 1] = 1
    # Check if graph is directed
    if output:
        for i in range(sol[0]):
            for j in range(i, sol[0]):
                if Graph[i][j] == 1 and Graph[j][i] == 1:
                    output = False
    # Find number of paths
    score = 0
    if output:
        A = Graph
        score += Graph[0][sol[0] - 1]
        for i in range(sol[0] + 1):
            new_Graph = [[0 for _ in range(sol[0])] for _ in range(sol[0])]
            for j in range(sol[0]):
                for z in range(sol[0]):
                    for l in range(sol[0]):
                        new_Graph[j][z] += Graph[j][l] * A[l][z]
            Graph = new_Graph
            score += Graph[0][sol[0] - 1]
    # Check if cycle exists
    if output:
        for i in range(sol[0]):
            for j in range(sol[0]):
                if Graph[i][j]:
                    output = False
                
    return output and k == score

# To należy ustawić do zadania
def gentest(k, output):
    return (k), output

def runtests( f, all_tests = 1 ):
    TESTS = []
    for spec in TEST_SPEC:
        newtest = {}
        arg, hint = gentest(*spec)
        newtest["arg"] = arg
        newtest["hint"] = hint
        TESTS.append(newtest)

    internal_runtests(copyarg, check, TESTS, f, ALLOWED_TIME, all_tests)

