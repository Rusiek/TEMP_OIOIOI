import os
ALLOWED_TIME = 20
# To należy ustawić ręcznie
TEST_NUM = 15

# format testów
# TESTS = [ {"arg":arg0, "hint": hint0}, {"arg":arg1, "hint": hint1}, ... ]

# To należy napisać zależnie od zadania
def make_test(i):
    path = os.path.dirname(os.path.abspath(__file__))
    file_in     = open(f"{path}\\TEST_DIR\\dag{'{:0>2}'.format(str(i))}.in", "r")
    file_out    = open(f"{path}\\TEST_DIR\\dag{'{:0>2}'.format(str(i))}.out", "r")

    # Tutaj należy napisać czytanie plików
    k = int(file_in.readline())
    output = [int(file_out.readline())]
    for i in range(output[0]):
        output.append(file_out.readline().rsplit(" "))
        for j in range(len(output[-1])):
            output[-1][j] = int(output[-1][j])
    
    file_in.close()
    file_out.close()

    return (k, output)

TEST_SPEC = [make_test(i) for i in range(TEST_NUM)] 