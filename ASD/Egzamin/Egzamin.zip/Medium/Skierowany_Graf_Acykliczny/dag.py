from dagtesty import runtests

def function(k):
    # Tutaj wprowadź kod
    # Na wyjściu powinny się znaleźć dwa obiekty
    # pierwszy: liczba wierzchołków zwracanego grafu
    # drugi: na i-tej pozycji tablica z dwiema liczbami, indeksami 
    # do jakich wychodzi krawędź z (i+1)-tego wierzchołka
    # Poniżej pierwszy i drugi argument z przykładowych danych
    # jako x oraz tab
    x = 6
    tab = [[3, 5], [6, -1], [2, 6], [2, 6], [6, -1], [-1, -1]]
    return x, tab

# zmien all_tests na: 
# 0 dla pierwszego progu złożoności 
# 1 dla drugiego progu złożoności
# 2 dla wzorcowego rozwiązania
runtests(function, all_tests = 2)
