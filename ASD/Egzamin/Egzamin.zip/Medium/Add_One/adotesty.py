# zad1testy.py
from testy import *
from adotest_spec import ALLOWED_TIME, TEST_SPEC

def copyarg( arg ):
    return arg

# To należy ustawić do zadania
def check(q, n, k, hint, sol):
    output = True
    if len(hint) != len(sol):
        output = False
    if output:
        for i in range(q):
            output = output and hint[i] == sol[i]

    return output

# To należy ustawić do zadania
def gentest(q, n, k, output):
    return (q, n, k), output

def runtests( f, all_tests = 1 ):
    TESTS = []
    for spec in TEST_SPEC:
        newtest = {}
        arg, hint = gentest(*spec)
        newtest["arg"] = arg
        newtest["hint"] = hint
        TESTS.append(newtest)

    internal_runtests(copyarg, check, TESTS, f, ALLOWED_TIME, all_tests)

