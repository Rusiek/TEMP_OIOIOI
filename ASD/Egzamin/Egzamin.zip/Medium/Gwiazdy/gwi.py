from gwitesty import runtests

def function(n, start, tab_l, tab_r):
    # Tutaj wprowadź kod
    return 9, [2, 4, 1, 3]

# zmien all_tests na: 
# 0 dla pierwszego progu złożoności 
# 1 dla drugiego progu złożoności
# 2 dla wzorcowego rozwiązania
runtests(function, all_tests = 2)
