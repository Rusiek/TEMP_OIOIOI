# zad1testy.py
from testy import *
from gwitest_spec import ALLOWED_TIME, TEST_SPEC

def copyarg( arg ):
    return arg

# To należy ustawić do zadania
def check(n, start, tab_l, tab_r, hint, sol):
    output = True
    
    if len(sol[1]) != n:
        output = False
    
    if sol[1][0] != start:
        output = False

    if output:
        vis = [False] * n
        vis[start - 1] = True
        score = 0
        for i in range(1, n):
            vis[sol[1][i]] = True
            if sol[1][i] == sol[1][i - 1]:
                output = False
            if sol[1][i] < 1:
                output = False
            if sol[1][i] > n:
                output = False
            if sol[1][i] < sol[1][i - 1]:
                score += tab_l[i - 1]
            else:
                score += tab_r[i - 1]
        
        output = score == hint
        for i in vis:
            output = output and i
            
    return output

# To należy ustawić do zadania
def gentest(n, start, tab_l, tab_r, output):
    return (n, start, tab_l, tab_r), output

def runtests( f, all_tests = 1 ):
    TESTS = []
    for spec in TEST_SPEC:
        newtest = {}
        arg, hint = gentest(*spec)
        newtest["arg"] = arg
        newtest["hint"] = hint
        TESTS.append(newtest)

    internal_runtests(copyarg, check, TESTS, f, ALLOWED_TIME, all_tests)

