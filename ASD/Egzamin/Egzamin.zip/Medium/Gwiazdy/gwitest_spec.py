import os
ALLOWED_TIME = 20
# To należy ustawić ręcznie
TEST_NUM = 15

# format testów
# TESTS = [ {"arg":arg0, "hint": hint0}, {"arg":arg1, "hint": hint1}, ... ]

# To należy napisać zależnie od zadania
def make_test(i):
    path = os.path.dirname(os.path.abspath(__file__))
    file_in     = open(f"{path}\\TEST_DIR\\gwi{'{:0>2}'.format(str(i))}.in", "r")
    file_out    = open(f"{path}\\TEST_DIR\\gwi{'{:0>2}'.format(str(i))}.out", "r")

    # Tutaj należy napisać czytanie plików
    temp = file_in.readline().rsplit(" ")
    n, start = int(temp[0]), int(temp[1])
    tab_l = []
    tab_r = []
    for i in range(n - 1):
        temp = file_in.readline().rsplit(" ")
        tab_l.append(int(temp[0]))
        tab_r.append(int(temp[1]))
    
    output = int(file_out.readline())

    file_in.close()
    file_out.close()

    return (n, start, tab_l, tab_r, output)

TEST_SPEC = [make_test(i) for i in range(TEST_NUM)] 