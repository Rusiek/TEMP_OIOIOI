from jeztesty import runtests

def solution(matrix):
    # Tutaj wprowadź kod
    return [0, 0, 0]

# zmien all_tests na: 
# 0 dla pierwszego progu złożoności 
# 1 dla drugiego progu złożoności
# 2 dla wzorcowego rozwiązania
runtests(solution, all_tests = 2)