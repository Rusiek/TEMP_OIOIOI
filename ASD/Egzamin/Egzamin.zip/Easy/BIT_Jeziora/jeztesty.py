# zad1testy.py
from testy import *
from jeztest_spec import ALLOWED_TIME, TEST_SPEC

def copyarg( arg ):
    return arg

# To należy ustawić do zadania
def check(matrix, hint, sol):
    output = True
    if len(hint) != len(sol):
        output = False
    if output:
        for i in range(len(hint)):
            output = output and hint[i] == sol[i]
    return output

# To należy ustawić do zadania
def gentest(matrix, output):
    return matrix, output

def runtests( f, all_tests ):
    TESTS = []
    for spec in TEST_SPEC:
        newtest = {}
        arg, hint = gentest(*spec)
        newtest["arg"] = arg
        newtest["hint"] = hint
        TESTS.append(newtest)

    internal_runtests(copyarg, check, TESTS, f, ALLOWED_TIME, all_tests)

